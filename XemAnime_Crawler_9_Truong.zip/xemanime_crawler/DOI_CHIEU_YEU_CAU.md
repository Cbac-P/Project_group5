# Đối chiếu bài crawling thứ 2

Đọc toàn bộ 26 trang PDF ban đầu và thông báo mới “mỗi bạn crawling 1 trang web cùng đề tài,
thống nhất models, lưu vào Database”. Bản riêng này chỉ phần crawler, không làm phần thứ 4.

| Yêu cầu | Bằng chứng |
|---|---|
| Python 3 / Requests / BeautifulSoup / SQLite | requirements.txt, crawler.py, parser.py, database.py |
| Một chủ đề, seed và config riêng | Movies & Entertainment, 2 seed HTML XemAnime, config.py |
| Một người / một website / common model / DB | Domain xemanime.org; schema movie-v2 9 trường; bảng movies/pages/links |
| Frontier BFS / visited / depth +1 | deque FIFO + set + frontier SQLite; local HTTP tests |
| Max pages/depth/timeout/delay | 100 pages, depth 3, timeout 15s, delay tối thiểu 2s; đều cấu hình được |
| robots / không vượt scope khi redirect | Snapshot robots và requests_log; fail closed; tests và audit |
| Trích URL/domain/title/text/depth/status/time | pages chứa đủ trường bắt buộc |
| Hyperlink, URL tương đối, loại protocol/file/domain | BeautifulSoup a[href], urljoin/normalize_url/url_reason, skip_reason |
| Không crawl lặp URL | Unique pages/frontier, seen khi enqueue, kiểm tra target redirect |
| HTTP 200/404/403/500/timeout/connection error | Tests với HTTP server local, ghi lỗi và xử lý tiếp hợp lý |
| Lưu DB ít nhất pages/links | Có đủ và có audit schema/integrity; movies bổ sung không thay thế |
| Summary từ dữ liệu thật, depth/HTTP/discovered/skip/failed | SQL summary; README mục 7; crawl_summary.json |
| README 7 phần | README mục 1–7 |
| Dataset chỉ 9 trường đã chốt | movies.jsonl, CSV 9 cột, bảng movies 9 cột, schema/tests |
| Có thể tiếp tục sau dừng, dùng riêng trên Windows | frontier bền vững, run.bat tự chuẩn bị môi trường |

**Kết quả kỹ thuật:** 25 tests đạt; audit dữ liệu mẫu 22/22 đạt.
100 trang là ngân sách triển khai, không khẳng định thầy yêu cầu tối thiểu 100 trang.
Depth 3 là trần; không bắt buộc mọi lớp đều có trang khi đạt cap sớm.

**Phạm vi domain:** PDF cũ yêu cầu 2–4 domain cho toàn bài; thông báo mới mỗi người một nguồn.
Bản XemAnime đáp ứng phần cá nhân, nhóm vẫn cần tổng hợp phần bốn thành viên khác.

**Giới hạn bằng chứng chính sách:** đã đọc robots và kiểm tra khả năng truy cập, khảo sát liên kết/tìm
điều khoản công khai nhưng chưa thấy điều khoản riêng đủ rõ. Không coi robots là giấy phép nội dung.
Không cố gửi request lỗi tới website thật để tạo số liệu; tình huống lỗi thử trên HTTP local.
Mọi con số trong README là snapshot chạy thử của công cụ, không phải khẳng định sinh viên đã thực hiện.
