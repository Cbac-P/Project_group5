import csv
import hashlib
import json
import tempfile
import unittest
from contextlib import closing
from pathlib import Path
from config import Config
from database import connect, export_all, read_movies, save_movie
from dataset import FIELDS, pack_submission, read_dataset, validate_movie
from parser import parse_page
from url_rules import RobotsRules, normalize_url, url_reason

URL = "https://xemanime.org/test-movie"
NOW = "2026-10-04T00:00:00+07:00"


def detail(kind="Movie", title="Phim thử", synopsis="Nhân vật du hành trong vũ trụ.", director="Tsutomu Shibayama", episodes="Full", json_url=URL):
    data = {"@type": kind, "name": title, "datePublished": "2025-06-01", "director": director,
            "actor": [{"name": "Người A"}, {"name": "Người B"}], "url": json_url}
    return '<title>Trang thử</title><div class="movie-detail"><h1 class="entry-title">' + title + '</h1>' + '''
      <p class="released"><a href="/release/1996">1996</a></p>
      <p>Quốc gia: <a>Nhật Bản</a> <a>Hoa Kỳ</a></p>
      <p>Thể loại: <a>Doraemon</a> <a>Phiêu Lưu</a></p></div>
      <div class="halim-episode"><a class="halim-btn">''' + episodes + '''</a></div>
      <div class="entry-content"><span>Nội dung phim</span><article class="item-content">''' + synopsis + '''</article>
      <span>Mở rộng...</span></div><p>Quảng cáo đặt vé</p><script type="application/ld+json">''' + json.dumps(data, ensure_ascii=False) + '</script>'


class XemAnimeChecks(unittest.TestCase):
    def test_fields_and_correct_synopsis_and_year(self):
        record = parse_page(detail(), URL, NOW)["movie"]
        self.assertEqual(set(record), set(FIELDS))
        self.assertEqual(record["release_year"], 1996)
        self.assertEqual(record["country"], ["Nhật Bản", "Hoa Kỳ"])
        self.assertEqual(record["genre"], ["Phiêu Lưu"])
        self.assertEqual(record["director"], ["Tsutomu Shibayama"])
        self.assertEqual(record["cast"], ["Người A", "Người B"])
        self.assertEqual(record["synopsis"], "Nhân vật du hành trong vũ trụ.")
        validate_movie(record)

    def test_category_jsonld_cannot_become_movie(self):
        page = '<h1>Phim lẻ</h1><script type="application/ld+json">{"@type":"Movie","name":"A"}</script>'
        self.assertIsNone(parse_page(page, "https://xemanime.org/phim-le", NOW)["movie"])

    def test_series_collections_episodes_and_wrong_url_excluded(self):
        for kwargs in ({"kind": "TVSeries"}, {"kind": "TVEpisode"}, {"title": "Doraemon Movie 1-45"},
                       {"title": "Tuyển tập phim"}, {"episodes": "1/12"}, {"episodes": "Tập 2"},
                       {"json_url": "https://xemanime.org/other-movie"}):
            with self.subTest(kwargs=kwargs):
                self.assertIsNone(parse_page(detail(**kwargs), URL, NOW)["movie"])

    def test_missing_content_is_empty_and_theme_director_removed(self):
        record = parse_page(detail(synopsis="", director="HaLim"), URL, NOW)["movie"]
        self.assertEqual(record["synopsis"], "")
        self.assertEqual(record["director"], [])

    def test_canonical_urls_player_query_and_scope(self):
        self.assertEqual(normalize_url("http://www.xemanime.org/test-movie/#a"), URL)
        self.assertEqual(normalize_url("https://xemanime.org/%74est-movie"), URL)
        self.assertIsNone(normalize_url("javascript:alert(1)"))
        self.assertIsNone(normalize_url("https://user:pass@xemanime.org/"))
        self.assertIsNone(url_reason("https://xemanime.org/phim-le/page/2", ["xemanime.org"]))
        for url in ("https://xemanime.org/watch-a/full-sv1.html", "https://xemanime.org/?s=abc",
                    "https://xemanime.org/wp-admin", "https://xemanime.org/movie.mp4", "https://example.com/a"):
            self.assertIsNotNone(url_reason(url, ["xemanime.org"]))

    def test_database_exports_and_portable_submission_match(self):
        record = parse_page(detail(), URL, NOW)["movie"]
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            with closing(connect(root / "crawler.db")) as db:
                save_movie(db, record)
                db.commit()
                export_all(db, root)
                self.assertEqual(read_movies(db), [record])
            self.assertEqual(read_dataset(root / "movies.jsonl"), [record])
            with (root / "movies.csv").open(encoding="utf-8-sig", newline="") as file:
                reader = csv.DictReader(file)
                rows = list(reader)
                self.assertEqual(reader.fieldnames, FIELDS)
                self.assertEqual(json.loads(rows[0]["country"]), record["country"])
            folder = pack_submission(root / "movies.jsonl", "member_a", "Fixture", root / "submissions")
            manifest = json.loads((folder / "manifest.json").read_text(encoding="utf-8"))
            self.assertEqual(manifest["record_count"], 1)
            self.assertEqual(manifest["sha256"], hashlib.sha256((folder / "movies.jsonl").read_bytes()).hexdigest())
            self.assertEqual(set(read_dataset(folder / "movies.jsonl")[0]), set(FIELDS))

    def test_schema_rejects_wrong_country_year_missing_or_extra_fields(self):
        record = parse_page(detail(), URL, NOW)["movie"]
        for key, value in (("country", "Nhật Bản"), ("release_year", True), ("cast", ["A", "A"])):
            with self.assertRaises(ValueError):
                validate_movie(dict(record, **{key: value}))
        with self.assertRaises(ValueError):
            validate_movie(dict(record, source_id="123"))
        del record["country"]
        with self.assertRaises(ValueError):
            validate_movie(record)


if __name__ == "__main__":
    unittest.main()
