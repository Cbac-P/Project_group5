"""Runnable checks of behavior, with a real local HTTP server and no public-site calls."""
import contextlib
import csv
import io
import json
import tempfile
import threading
import time
import unittest
from unittest.mock import patch
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import requests
from config import Config
from crawler import Crawler
from database import connect, export_all, save_page, summary
from parser import parse_page
from url_rules import RobotsRules, normalize_url, url_reason

class Handler(BaseHTTPRequestHandler):
    routes = {}
    hits = []

    def do_GET(self):
        type(self).hits.append(self.path)
        status, headers, body, pause = self.routes.get(self.path, (404, {}, '', 0))
        if pause:
            time.sleep(pause)
        if status == 0:
            self.close_connection = True
            return
        self.send_response(status)
        for key, value in headers.items():
            self.send_header(key, value)
        self.end_headers()
        try:
            self.wfile.write(body.encode('utf-8'))
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
            pass

    def log_message(self, *args):
        pass

def html(body):
    return (200, {'Content-Type': 'text/html; charset=utf-8'}, f'<html><head><title>Phim tiếng Việt</title></head><body>{body}</body></html>', 0)

class CrawlerChecks(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        cls.origin = f'http://127.0.0.1:{cls.server.server_port}'

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join()

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.folder = Path(self.temp.name)
        Handler.hits = []
        Handler.routes = {'/robots.txt': (200, {'Content-Type': 'text/plain'}, 'User-agent: *\nDisallow: /blocked\n', 0)}

    def crawl(self, seeds, **options):
        config = Config(seeds=[self.origin + seed for seed in seeds], allowed_domains=['127.0.0.1'], delay=0, db_path=self.folder / 'crawler.db', output_dir=self.folder, **options)
        db = connect(config.db_path)
        with contextlib.redirect_stdout(io.StringIO()):
            Crawler(config, db).run()
        return db

    def test_bfs_depth_errors_and_enqueue_deduplication(self):
        Handler.routes.update({'/seed': html('<a href="/a">A</a><a href="/b">B</a><a href="/a#part">dup</a><a href="/blocked">blocked</a><a href="/x.jpg">image</a><a href="mailto:person@example.com">email</a>'), '/a': html('<a href="/a1">A1</a><a href="/b">same B</a>'), '/b': (404, {}, '', 0), '/a1': html('<a href="/too-deep">no</a>')})
        db = self.crawl(['/seed'], max_depth=2)
        rows = list(db.execute('SELECT url,depth,status_code FROM pages ORDER BY id'))
        self.assertEqual([row[0].removeprefix(self.origin) for row in rows], ['/seed', '/a', '/b', '/a1'])
        self.assertEqual([row[1] for row in rows], [0, 1, 1, 2])
        self.assertEqual(rows[2][2], 404)
        self.assertEqual(Handler.hits.count('/a'), 1)
        self.assertNotIn('/blocked', Handler.hits)
        self.assertNotIn('/too-deep', Handler.hits)
        self.assertEqual(summary(db)['failed_requests'], 1)
        self.assertGreater(db.execute('SELECT COUNT(*) FROM links').fetchone()[0], 3)
        db.close()

    def test_page_budget_and_resume_no_repeated_http(self):
        Handler.routes.update({'/seed': html('<a href="/a">A</a><a href="/b">B</a>'), '/a': html('A'), '/b': html('B')})
        db = self.crawl(['/seed'], max_pages=2)
        self.assertEqual(summary(db)['pages_crawled'], 2)
        self.assertEqual(summary(db)['pending_urls'], 1)
        db.close()
        db = self.crawl(['/seed'], max_pages=3)
        self.assertEqual(summary(db)['pages_crawled'], 3)
        self.assertEqual(Handler.hits.count('/seed'), 1)
        self.assertEqual(Handler.hits.count('/a'), 1)
        self.assertEqual(Handler.hits.count('/b'), 1)
        db.close()

    def test_percent_encoded_unreserved_url_is_not_requested_twice(self):
        Handler.routes.update({'/seed': html('<a href="/a">A</a><a href="/%61">Alias A</a>'), '/a': html('A')})
        db = self.crawl(['/seed'])
        self.addCleanup(db.close)
        self.assertEqual(Handler.hits.count('/a'), 1)
        self.assertEqual(summary(db)['pages_crawled'], 2)
        db.close()

    def test_domain_budget_keeps_bfs_layer_before_resume(self):
        other = self.origin.replace('127.0.0.1', 'localhost')
        Handler.routes.update({'/seed-a': html('<a href="/a1">A1</a>'), '/seed-a-extra1': html('A extra seed 1'), '/seed-a-extra2': html('A extra seed 2'), '/seed-b': html('<a href="/b1">B1</a>'), '/a1': html('<a href="/a2">A2</a>'), '/b1': html('<a href="/b2">B2</a>'), '/a2': html('A2'), '/b2': html(f'<a href="{self.origin}/a2">A2</a>')})
        config = Config(seeds=[self.origin + '/seed-a', self.origin + '/seed-a-extra1', self.origin + '/seed-a-extra2', other + '/seed-b'], allowed_domains=['127.0.0.1', 'localhost'], delay=0, max_pages=20, max_pages_per_domain=3, db_path=self.folder / 'crawler.db', output_dir=self.folder)
        db = connect(config.db_path)
        self.addCleanup(db.close)
        with contextlib.redirect_stdout(io.StringIO()):
            Crawler(config, db).run()
        config.max_pages_per_domain = 10
        with contextlib.redirect_stdout(io.StringIO()):
            Crawler(config, db).run()
        depths = [r[0] for r in db.execute('SELECT depth FROM pages ORDER BY id')]
        self.assertEqual(depths, sorted(depths))
        self.assertEqual(db.execute('SELECT depth FROM pages WHERE url=?', (self.origin + '/a2',)).fetchone()[0], 2)
        self.assertEqual(Handler.hits.count('/a2'), 1)
        self.assertEqual(Handler.hits.count('/b2'), 1)
        db.close()

    def test_external_redirect_is_never_requested(self):
        Handler.routes['/redirect'] = (302, {'Location': f'http://localhost:{self.server.server_port}/poison'}, '', 0)
        db = self.crawl(['/redirect'])
        self.assertNotIn('/poison', Handler.hits)
        self.assertIn('outside_domain', db.execute('SELECT error FROM pages').fetchone()[0])
        db.close()

    def test_redirect_target_is_not_fetched_again(self):
        Handler.routes.update({'/redirect': (302, {'Location': '/target'}, '', 0), '/target': html('Target')})
        db = self.crawl(['/redirect', '/target'])
        self.assertEqual(Handler.hits.count('/target'), 1)
        self.assertEqual(summary(db)['pages_crawled'], 1)
        db.close()

    def test_failed_robots_fail_closed(self):
        Handler.routes['/robots.txt'] = (503, {}, '', 0)
        Handler.routes['/seed'] = html('Must not download')
        db = self.crawl(['/seed'])
        self.assertNotIn('/seed', Handler.hits)
        self.assertEqual(db.execute('SELECT crawl_status FROM pages').fetchone()[0], 'blocked')
        db.close()

    def test_timeout_and_binary_response_do_not_stop_other_pages(self):
        Handler.routes.update({'/slow': (200, {'Content-Type': 'text/html'}, 'slow', 0.2), '/binary': (200, {'Content-Type': 'image/png'}, 'binary', 0), '/fine': html('Fine')})
        db = self.crawl(['/slow', '/binary', '/fine'], timeout=0.05)
        self.assertEqual([r[0] for r in db.execute('SELECT crawl_status FROM pages ORDER BY id')], ['request_error', 'non_html', 'ok'])
        db.close()

    def test_connection_error_is_recorded_and_next_page_continues(self):
        Handler.routes.update({'/disconnect': (0, {}, '', 0), '/fine': html('Fine')})
        db = self.crawl(['/disconnect', '/fine'])
        self.addCleanup(db.close)
        rows = list(db.execute('SELECT crawl_status,status_code FROM pages ORDER BY id'))
        self.assertEqual([(r[0], r[1]) for r in rows], [('request_error', None), ('ok', 200)])
        self.assertEqual(summary(db)['failed_requests'], 1)

    def test_http_500_continues_and_403_stops_only_its_host(self):
        other = self.origin.replace('127.0.0.1', 'localhost')
        Handler.routes.update({'/seed-a': html('<a href="/server-error">500</a><a href="/fine">Fine</a><a href="/forbidden">403</a><a href="/skip-after-403">Skip</a>'), '/seed-b': html('<a href="/other-host-fine">Other host</a>'), '/server-error': (500, {}, '', 0), '/forbidden': (403, {}, '', 0), '/fine': html('Fine'), '/skip-after-403': html('Must not request'), '/other-host-fine': html('Still crawl other host')})
        config = Config(seeds=[self.origin + '/seed-a', other + '/seed-b'], allowed_domains=['127.0.0.1', 'localhost'], delay=0, db_path=self.folder / 'crawler.db', output_dir=self.folder)
        db = connect(config.db_path)
        self.addCleanup(db.close)
        with contextlib.redirect_stdout(io.StringIO()):
            Crawler(config, db).run()
        self.assertEqual(summary(db)['failed_requests'], 2)
        self.assertIn('/fine', Handler.hits)
        self.assertIn('/other-host-fine', Handler.hits)
        self.assertNotIn('/skip-after-403', Handler.hits)

    def test_robots_wildcard_longest_rule_and_agent_group(self):
        rules = RobotsRules('User-agent: *\nAllow: /\nDisallow: /*?\nDisallow: /_next/\nAllow: /_next/open$\n', 'VietnameseFilmCrawler/1.0')
        self.assertTrue(rules.allows('https://www.momo.vn/cinema/a-1'))
        self.assertFalse(rules.allows('https://www.momo.vn/cinema/a-1?page=2'))
        self.assertFalse(rules.allows('https://www.momo.vn/_next/a'))
        self.assertTrue(rules.allows('https://www.momo.vn/_next/open'))
        self.assertFalse(rules.allows('https://www.momo.vn/_next/open/more'))
        specific = RobotsRules('User-agent: *\nDisallow: /\nUser-agent: FilmBot\nAllow: /\nCrawl-delay: 5\n', 'FilmBot/1')
        self.assertTrue(specific.allows('https://example.com/a'))
        self.assertEqual(specific.delay, 5)

    def test_resume_cannot_change_bfs_depth_or_seeds(self):
        Handler.routes['/seed'] = html('Seed')
        db = self.crawl(['/seed'], max_depth=2)
        before = list(Handler.hits)
        config = Config(seeds=[self.origin + '/seed'], allowed_domains=['127.0.0.1'], max_depth=3, delay=0, output_dir=self.folder)
        with self.assertRaisesRegex(ValueError, 'max_depth'):
            Crawler(config, db)
        config.max_depth = 2
        config.seeds = [self.origin + '/different']
        with self.assertRaisesRegex(ValueError, 'seeds'):
            Crawler(config, db)
        self.assertEqual(before, Handler.hits)
        db.close()

    def test_parser_error_keeps_html_and_continues(self):
        Handler.routes.update({'/bad-parser': html('Cache must survive'), '/good': html('Good')})
        parsed_good = parse_page(html('Good')[2], self.origin + '/good', '2026-10-04T00:00:00+00:00')
        with patch('crawler.parse_page', side_effect=[ValueError('changed markup'), parsed_good]):
            db = self.crawl(['/bad-parser', '/good'])
        rows = list(db.execute('SELECT crawl_status,html_path FROM pages ORDER BY id'))
        self.assertEqual([row[0] for row in rows], ['parse_error', 'ok'])
        self.assertIn('Cache must survive', Path(rows[0][1]).read_text(encoding='utf-8'))
        db.close()

    def test_invalid_movie_is_logged_and_next_page_continues(self):
        Handler.routes.update({'/invalid-movie': html('Bad movie metadata'), '/good': html('Good')})
        good = parse_page(html('Good')[2], self.origin + '/good', '2026-10-04T00:00:00+00:00')
        invalid = dict(good, movie={'country': 'wrong type'})
        with patch('crawler.parse_page', side_effect=[invalid, good]):
            db = self.crawl(['/invalid-movie', '/good'])
        self.addCleanup(db.close)
        self.assertEqual([r[0] for r in db.execute('SELECT crawl_status FROM pages ORDER BY id')], ['parse_error', 'ok'])
        self.assertEqual(db.execute('SELECT COUNT(*) FROM movies').fetchone()[0], 0)
if __name__ == '__main__':
    unittest.main()
