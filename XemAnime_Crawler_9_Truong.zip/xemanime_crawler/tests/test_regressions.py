"""Checks for problems found during the requested review; no public HTTP calls."""
import contextlib
import io
import json
import tempfile
import unittest
from dataclasses import asdict
from pathlib import Path
from unittest.mock import patch

import main
from config import Config
from database import connect
from parser import parse_page
from test_xemanime import detail, URL, NOW


class ReviewRegressions(unittest.TestCase):
    def fixture_db(self, folder, depth=3):
        path = folder / "crawler.db"
        config = Config(max_pages=300, max_pages_per_domain=300, max_depth=depth,
                        timeout=7, delay=3, db_path=path, output_dir=folder, member="Fixture owner")
        db = connect(path)
        with db:
            db.execute("INSERT INTO metadata VALUES('config',?)", (json.dumps(asdict(config), default=str),))
            db.executemany("INSERT INTO pages(url,domain,depth,crawled_at,crawl_status) VALUES(?,?,?,?,?)",
                           [(f"https://xemanime.org/fixture-{i}", "xemanime.org", 1, NOW, "ok") for i in range(300)])
        db.close()
        return path

    def invoke(self, path, *options):
        with patch("sys.argv", ["main.py", "crawl", "--db", str(path), *options]), contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
            main.main()

    def test_default_resume_retains_depth_delay_timeout_and_page_budget(self):
        with tempfile.TemporaryDirectory() as temp:
            path = self.fixture_db(Path(temp), depth=2)
            with patch("crawler.requests.Session.get", side_effect=AssertionError("No public requests")):
                self.invoke(path)
            db = connect(path)
            current = json.loads(db.execute("SELECT value FROM metadata WHERE key='config'").fetchone()[0])
            db.close()
            self.assertEqual((current["max_depth"], current["delay"], current["timeout"], current["max_pages"]), (2, 3, 7, 300))

    def test_lower_cap_rejected_without_changing_stored_configuration(self):
        with tempfile.TemporaryDirectory() as temp:
            path = self.fixture_db(Path(temp))
            db = connect(path)
            before = db.execute("SELECT value FROM metadata WHERE key='config'").fetchone()[0]
            db.close()
            with self.assertRaises(SystemExit) as error:
                self.invoke(path, "--max-pages", "100")
            self.assertEqual(error.exception.code, 1)
            db = connect(path)
            self.assertEqual(db.execute("SELECT value FROM metadata WHERE key='config'").fetchone()[0], before)
            db.close()

    def test_pack_cannot_reassign_owner(self):
        with tempfile.TemporaryDirectory() as temp:
            path = self.fixture_db(Path(temp))
            with patch("sys.argv", ["main.py", "pack", "--db", str(path), "--member", "Different owner"]), patch("main.pack_submission") as pack, contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
                with self.assertRaises(SystemExit) as error:
                    main.main()
                self.assertEqual(error.exception.code, 1)
                pack.assert_not_called()

    def test_unrelated_jsonld_cannot_override_current_movie(self):
        related = '<script type="application/ld+json">' + json.dumps({"@type": "TVSeries", "url": "https://xemanime.org/another-series"}) + '</script>'
        self.assertIsNotNone(parse_page(related + detail(), URL, NOW)["movie"])
        self.assertIsNone(parse_page(detail(json_url=None), URL, NOW)["movie"])


if __name__ == "__main__":
    unittest.main()
